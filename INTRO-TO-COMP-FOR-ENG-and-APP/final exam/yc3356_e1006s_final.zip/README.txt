This Final Exam is completed by Yi Chen with UNI yc3356.
The platform is Jupyter Version: 5.4.1
The language is Python 3.6
